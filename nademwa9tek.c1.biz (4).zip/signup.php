<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Replace with your actual database credentials
    $servername = "fdb1027.biz.nf";
    $username = "4327137_jasser";
    $password = "jasserra12457";
    $dbname = "4327137_jasser";

    // Create a connection to the database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get user input
    $nom = $_POST["nom"];
    $prenom = $_POST["prenom"];
    $telephone = $_POST["telephone"];
    $bac_annee = $_POST["bac-annee"];
    $option = $_POST["option"];
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm-password"];

    // Check if the password and confirm_password match
    if ($password !== $confirm_password) {
        echo "<script>alert('Password and Confirm Password do not match');</script>";
    } else {
        // Check if the username or email already exists in the database
        $query = "SELECT * FROM `nademwa9tek` WHERE telephone = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $telephone);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<script>alert('Telephone already exists');</script>";
        } else {
            // Generate a unique ID
            $uniqId = rand(100000000000, 999999999999);

            // Hash the password for security
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert the user data into the database
            $query = "INSERT INTO `nademwa9tek` (userID, telephone, nom, prenom, password, section_bac, bac_annee) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("issssss", $uniqId, $telephone, $nom, $prenom, $hashedPassword, $option, $bac_annee);

            if ($stmt->execute()) {
                // Save user data as JSON
                $userData = array(
                    'telephone' => $telephone,
                    'nom' => $nom,
                    'prenom' => $prenom,
                    'section_bac' => $option,
                    'bac_annee' => $bac_annee
                );

                // Specify the directory where you want to save the JSON file
                $directory = 'user_data/';

                // Check if the directory exists, if not, create it
                if (!is_dir($directory)) {
                    mkdir($directory, 0755, true);
                }

                // Generate a unique filename using the uniqId
                $filename = $directory . $uniqId . '.json';

                // Convert the array to a JSON string
                $jsonData = json_encode($userData);

                // Save the JSON data into the file
                file_put_contents($filename, $jsonData);

                // Password is not saved in the JSON data
                unset($userData['password']);

                // Redirect the user to "index.html"
                header("Location: index.html");
                exit();
            } else {
                // Handle any errors during the insert
                echo "Error: " . $conn->error;
            }
        }
    }

    // Close the database connection
    $conn->close();
}
?>
