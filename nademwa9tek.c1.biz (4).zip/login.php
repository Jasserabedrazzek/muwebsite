<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Replace with your actual database credentials
    $servername = "fdb1027.biz.nf";
    $username = "4327137_jasser";
    $password = "jasserra12457";
    $dbname = "4327137_jasser";

    // Create a connection to the database
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get user input
    $tel = $_POST['tel_user'];
    $pass = $_POST['passe_user'];

    // Check if the telephone number exists in the database
    $query = "SELECT * FROM `nademwa9tek` WHERE telephone = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $tel);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo "<script>alert('Telephone number not found. Please check your credentials or sign up.');</script>";
    } else {
        // Verify the password
        $user = $result->fetch_assoc();
        if (password_verify($pass, $user['password'])) {
            // Password is correct, get the userID
            $userID = $user['userID'];

            // Now you have the $userID, you can use it as needed
            // For example, you can store it in a session variable for future use
            session_start();
            $_SESSION['userID'] = $userID;

            // Redirect to home.html or any other page
            header("Location: home.php?userID=" . $userID);
            exit();
        } else {
            // Incorrect password
            echo "<script>alert('Incorrect password. Please try again.');</script>";
            exit();
        }
    }

    // Close the database connection
    $conn->close();
}
?>
