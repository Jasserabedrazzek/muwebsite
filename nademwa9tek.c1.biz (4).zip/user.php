<?php
// Replace with your actual database credentials
$$servername = "fdb1027.biz.nf";
$username = "4327137_jasser";
$password = "jasserra12457";
$dbname = "4327137_jasser";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the userID from the URL parameter 'userID'
$userID = $_GET['userID'];

// Prepare the SQL query to fetch user information
$sql = "SELECT * FROM `nademwa9tek` WHERE id = $userID";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // User found, fetch and return user information (You can customize this part as per your database structure)
    $row = $result->fetch_assoc();
    $user_info = array(
        'nom' => $row['name'],
        'prenom' => $row['lastname'],
        'telephone' => $row['telephone'],
        'section_bac' => $row['bac'],
        'bac_annee' => $row['bac_annee']
    );

    // Return user information in JSON format
    echo json_encode($user_info);
} else {
    // User not found or invalid userID, redirect to index.html
    header("Location: index.html");
    exit;
}

$conn->close();
?>
